package upi.constant;

public class UPICodes {

    public static int OK_CODE = 0000;
    public static String OK_MSG = "OK";

    public static int ACCESS_DENIED_ERROR = 403;
    public static String ACCESS_DENIED_ERROR_MSG = "ACCESS DENIED";

    public static final int NO_ACTIVE_VPA = 10001;
    public static final String NO_ACTIVE_VPA_MSG = "No Active VPA" ;

    public static final int DEVICE_NOT_REGISTERED = 10002;
    public static final String DEVICE_NOT_REGISTERED_MSG = "Device not registered";

    public static final int REF_TXN_NOT_FOUND = 10003;
    public static final String REF_TXN_NOT_FOUND_MSG = "Reference Txn not found";

    public static final int DYNAMIC_QR_REPAYMENT = 10004;
    public static final String DYNAMIC_QR_REPAYMENT_MSG = "Dynamic QR Repayment not allowed";

    public static final int URL_MALFORMED = 10005;
    public static final String URL_MALFORMED_MSG = "Url malformed";

    public static final int AMOUNT_MISMATCH_FOR_DYNAMIC_QR = 10006;
    public static final String AMOUNT_MISMATCH_FOR_DYNAMIC_QR_MSG = "Amount mismatch for dynamic QR";

    public static final int NOT_AN_ACTIVE_UPI_CUSTOMER = 10007;
    public static final String NOT_AN_ACTIVE_UPI_CUSTOMER_MSG = "Not an active UPI customer";

    public static final int PAYMENT_SUSPENDED_TILL_ERROR = 10008;
    public static final String PAYMENT_SUSPENDED_TILL_ERROR_MSG = "Payments have been suspended for you because of wrong mpins entered. Please try after {0} min";

    public static final int INVALID_MPIN = 10009;
    public static final String INVALID_MPIN_MSG = "Invalid Mpin";

    public static final int PAYER_PAYEE_SAME = 10010;
    public static final String PAYER_PAYEE_SAME_MSG = "Payer Payee cannot be same";

    public static final int VPA_NOT_VALIDATED = 10011;
    public static final String VPA_NOT_VALIDATED_MSG = "VPA not validated";

    public static final int VPA_BLOCK= 10012;
    public static final String VPA_BLOCK_MSG = "VPA is blocked for transaction.";

    public static final int  UPI_P2P_TRANSACTIONS_NOT_ALLOWED = 10013;
    public static final String UPI_P2P_TRANSACTIONS_NOT_ALLOWED_MSG = "Payments through UPI can only be done towards merchants.";

    public static final int CANNOT_USE_DOF = 10014;
    public static final String CANNOT_USE_DOF_MSG = "Cannot use DOF for this transaction";

    public static final int DOF_NOT_ENABLED = 10015;
    public static final String DOF_NOT_ENABLED_MSG = "DOF not allowed for this transaction";

    public static final int INVALID_QR_STRING = 10016;
    public static final String INVALID_QR_STRING_MSG = "You cannot make payment through this QR";

    public static final int INVALID_PAYMENT_TYPE = 100022;
    public static final String INVALID_PAYMENT_TYPE_MSG = "Invalid payment type";

    public static final int INVALID_AMOUNT = 100019;
    public static final String INVALID_AMOUNT_MSG = "Invalid amount entered";

    public static final int NO_MPIN_FOUND = 100041;
    public static final String NO_MPIN_FOUND_MSG = "No Mpin passed";

    public static final int INVALID_NARRATION_LENGTH = 100024;
    public static final String INVALID_NARRATION_LENGTH_MSG = "Narration cannot be greater than 100 chars";

    public static final int PAYEE_ADDRESS_REQUIRED = 100014;
    public static final String PAYEE_ADDRESS_REQUIRED_MSG = "Payee Address is required";

    public static final int EMPTY_QR_STRING = 100046;
    public static final String EMPTY_QR_STRING_MSG = "Empty QR String";

    public static final int NO_TXN_ID_PASSED = 100026;
    public static final String NO_TXN_ID_PASSED_MSG = "No Txn Id passed";

    public static final int NO_TXN_TYPE_PASSED = 100089;
    public static final String NO_TXN_TYPE_PASSED_MSG = "NO UPI Transaction Type Passed.";

    public static final int INVALID_LAT_LONG = 100050;
    public static final String INVALID_LAT_LONG_MSG = "Your location services may be switched off. Please switch them on from your phone settings and try again.";

    public static final int NO_IP_ADDRESS = 100010;
    public static final String NO_IP_ADDRESS_MSG = "No IP Address present";

    public static final int NO_OS_PRESENT = 100051;
    public static final String NO_OS_PRESENT_MSG = "No OS present";
}
