package upi.constant;

public class UPIConstants {

    // request attribute key for user data
    public static final String USER_DATA_KEY = "userData";
    public static String DEFAULT_INITIATION_MODE = "00";
    public static String DEFAULT_REF_CATEGORY = "00";
    public static String DEFAULT_PURPOSE = "00";
    public static String DEAFULT_ORG_ID = "000000";
    public static int CUSTOMER_MCC_CODE = 0000;
    public static String UPI_DEFAULT_NOTE = "Dhani UPI Transaction";
    public static final String UPI_PAYMENT_TXN_TYPE_CODE = "UPI_PAY";
    public static final String INR = "INR";
    public static String ALLOWED_INITIATION_MODE = "00";
    public static String IND_COUNTRY_CODE = "91";
    public static String UPI_WALLET_DEBIT_FAILED = "Upi Wallet Debit Failed";
    public static int VPA_VALIDATION_DURATION_DAYS = 30;
}
