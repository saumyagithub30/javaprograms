package upi.constant;

public class UrlConstant {

    public static final String UPI_MAKE_PAYMENT = "/upi/v1/pay";
    public static final String OLIVE_PAY_URI = "/upi/olive/v1/pay";

}
