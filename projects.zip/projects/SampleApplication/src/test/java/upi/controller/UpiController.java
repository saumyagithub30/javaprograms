package upi.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.UnsupportedEncodingException;

import upi.constant.UPIConstants;
import upi.constant.UrlConstant;
import upi.constant.UPICodes;
import upi.annotation.Authentication;
import upi.model.request.UpiPaymentRequest;
import upi.model.response.UPIApiResponseInfo;
import upi.model.response.UpiMakePaymentResponse;
import upi.model.request.UserData;
import upi.service.UpiService;
import upi.exception.FinalUdioException;

@RestController
public class UpiController {

    @Autowired
    UpiService upiService;

    @Authentication(openToUser = true)
    @RequestMapping(value = UrlConstant.UPI_MAKE_PAYMENT, method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UPIApiResponseInfo> makePayment(@RequestAttribute(UPIConstants.USER_DATA_KEY) UserData userData, @RequestBody UpiPaymentRequest upiPaymentRequest,
                                                          HttpServletRequest servRequest, HttpServletResponse servletResponse) throws FinalUdioException, UnsupportedEncodingException
    {
        UpiMakePaymentResponse response = upiService.makePayment(userData, upiPaymentRequest);
        return new ResponseEntity<>(new UPIApiResponseInfo(UPICodes.OK_CODE, UPICodes.OK_MSG, response), HttpStatus.OK);
    }

}
