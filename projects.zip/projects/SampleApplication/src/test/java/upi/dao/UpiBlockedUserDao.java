package upi.dao;

import upi.model.db.UpiBlockedUserModel;

import java.util.List;

public interface UpiBlockedUserDao {
    public void save( UpiBlockedUserModel upiBlockedUserModel);

    public void update( UpiBlockedUserModel upiBlockedUserModel);

    public List<UpiBlockedUserModel> getBlockedUsers( String user, String userType);

    public UpiBlockedUserModel getRecordBySourceAndDest(String sourceVpa, String destVpa);
}
