package upi.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import upi.annotation.ReadOnlyConnection;
import upi.annotation.WriteOnlyConnection;
import upi.model.db.UpiBlockedUserModel;

import java.util.List;

@Component
public class UpiBlockedUserDaoWrapper {

    @Autowired
    private UpiBlockedUserDao upiBlockedUserDao;

    @WriteOnlyConnection
    public void save(UpiBlockedUserModel upiBlockedUserModel)
    {
        upiBlockedUserDao.save(upiBlockedUserModel);
    }

    @WriteOnlyConnection
    public void update(UpiBlockedUserModel upiBlockedUserModel)
    {
        upiBlockedUserDao.update(upiBlockedUserModel);
    }

    @ReadOnlyConnection
    public List<UpiBlockedUserModel> getBlockedUsers(String user, String userType)
    {
        return upiBlockedUserDao.getBlockedUsers(user, userType);
    }

    @ReadOnlyConnection
    public UpiBlockedUserModel getRecordBySourceAndDest(String source, String dest)
    {
        return upiBlockedUserDao.getRecordBySourceAndDest(source, dest);
    }
}
