package upi.dao;

import org.springframework.stereotype.Repository;
import upi.model.db.UpiCustomerModel;

@Repository
public interface UpiCustomerDao {

    public UpiCustomerModel getActiveCustomerModelByMobileNumber(String mobileNumber);

    public void updateById(UpiCustomerModel upiCustomerModel);
}
