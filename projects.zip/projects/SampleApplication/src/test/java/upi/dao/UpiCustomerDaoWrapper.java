package upi.dao;

import org.springframework.beans.factory.annotation.Autowired;
import upi.annotation.ReadOnlyConnection;
import upi.annotation.WriteOnlyConnection;
import upi.model.db.CreditlineApplication;
import upi.model.db.UpiCustomerModel;

public class UpiCustomerDaoWrapper implements UpiCustomerDao{

    @Autowired
    private UpiCustomerDao upiCustomerDao;

    @ReadOnlyConnection
    public UpiCustomerModel getActiveCustomerModelByMobileNumber(String mobileNumber) {
        return null;
    }

    @WriteOnlyConnection
    public void updateById(UpiCustomerModel upiCustomerModel)
    {
        upiCustomerDao.updateById(upiCustomerModel);
    }

    public CreditlineApplication getCreditlineApplicationByMobile(String name, String mobileNumber) {
        return null;
    }
}
