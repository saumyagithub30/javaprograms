package upi.dao;

import upi.annotation.ReadOnlyConnection;

@ReadOnlyConnection
public interface UpiCustomerDeviceBindingDao {

    public Boolean isDeviceBinded( String mobileNumber, String deviceId);

}
