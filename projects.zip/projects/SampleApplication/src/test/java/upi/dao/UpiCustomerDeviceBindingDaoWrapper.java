package upi.dao;

import org.springframework.beans.factory.annotation.Autowired;
import upi.annotation.ReadOnlyConnection;

public class UpiCustomerDeviceBindingDaoWrapper {

    @Autowired
    private UpiCustomerDeviceBindingDao upiCustomerDeviceBindingDao;

    @ReadOnlyConnection
    public Boolean isDeviceBinded(String mobileNumber, String deviceId)
    {
        return upiCustomerDeviceBindingDao.isDeviceBinded(mobileNumber, deviceId);
    }
}
