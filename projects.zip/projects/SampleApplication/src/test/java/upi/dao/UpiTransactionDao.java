package upi.dao;

import org.springframework.stereotype.Repository;
import upi.model.db.UpiTransactionModel;
import upi.utils.enums.UpiEnums;

@Repository
public interface UpiTransactionDao {

    public void save(UpiTransactionModel upiTransactionModel);

    public void updateById(UpiTransactionModel upiTransactionModel);

    public UpiTransactionModel getTransactionByCodeAndTxnType(String txnCode, UpiEnums.UpiTxnType txnType);



}
