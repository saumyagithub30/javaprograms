package upi.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import upi.annotation.ReadOnlyConnection;
import upi.annotation.WriteOnlyConnection;
import upi.model.db.UpiTransactionModel;
import upi.utils.enums.UpiEnums;

@Repository
public class UpiTransactionDaoWrapper{

    @Autowired
    UpiTransactionDao upiTransactionDao;

    @WriteOnlyConnection
    public void save(UpiTransactionModel upiTransactionModel)
    {
        upiTransactionDao.save(upiTransactionModel);
    }

    @WriteOnlyConnection
    public void updateById(UpiTransactionModel upiTransactionModel)
    {
        upiTransactionDao.updateById(upiTransactionModel);
    }

    @ReadOnlyConnection
    public UpiTransactionModel getTransactionByCodeAndTxnType(String txnCode, UpiEnums.UpiTxnType txnType) {
        return null;
    }
}
