package upi.dao;

import org.springframework.stereotype.Repository;
import upi.model.db.VpaModel;

import java.util.List;

@Repository
public interface VpaDao {

    public VpaModel getActiveVpaByMobileNumber(String mobileNumber);

    public VpaModel getLatestVpaModelByMobileNumber(String mobileNumber);

    public VpaModel getByAddress(String address);

    List<VpaModel> getRegisteredVpaModelsByMobileNumber(String mobileNumber);
}
