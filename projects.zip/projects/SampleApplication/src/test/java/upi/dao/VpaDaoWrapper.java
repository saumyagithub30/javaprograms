package upi.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import upi.annotation.ReadOnlyConnection;
import upi.model.db.VpaModel;

import java.util.List;

@Component
public class VpaDaoWrapper {

    @Autowired
    private VpaDao vpaDao;

    @ReadOnlyConnection
    public VpaModel getActiveVpaByMobileNumber(String mobileNumber)
    {
        return vpaDao.getActiveVpaByMobileNumber(mobileNumber);
    }

    @ReadOnlyConnection
    public VpaModel getLatestVpaModelByMobileNumber(String mobileNumber)
    {
        return vpaDao.getLatestVpaModelByMobileNumber(mobileNumber);
    }

    @ReadOnlyConnection
    public VpaModel getByAddress(String payeeAddress) {
        return vpaDao.getByAddress(payeeAddress);
    }

    public List<VpaModel> getRegisteredVpaModelsByMobileNumber(String mobileNumber) {
        return vpaDao.getRegisteredVpaModelsByMobileNumber(mobileNumber);
    }
}
