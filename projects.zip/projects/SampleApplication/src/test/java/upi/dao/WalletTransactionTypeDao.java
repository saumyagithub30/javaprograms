package upi.dao;

import upi.model.db.WalletTransactionType;

import java.util.List;

public interface WalletTransactionTypeDao {
    WalletTransactionType getWalletTransactionTypeByCode(String typeCode);

    List<WalletTransactionType> getWalletTransactionTypes();
}
