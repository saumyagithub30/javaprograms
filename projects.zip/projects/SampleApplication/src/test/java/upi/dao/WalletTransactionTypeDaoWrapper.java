package upi.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import upi.annotation.ReadOnlyConnection;
import upi.model.db.WalletTransactionType;

import java.util.List;

@Service
public class WalletTransactionTypeDaoWrapper {

    @Autowired
    private WalletTransactionTypeDao wallettransactiontypedao;

    @ReadOnlyConnection
    public WalletTransactionType getWalletTransactionTypeByCode(String typeCode)
    {
        return wallettransactiontypedao.getWalletTransactionTypeByCode(typeCode);
    }

    @ReadOnlyConnection
    public List<WalletTransactionType> getWalletTransactionTypes()
    {
        return wallettransactiontypedao.getWalletTransactionTypes();
    }
}
