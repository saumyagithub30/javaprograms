package upi.exception;

import lombok.Getter;
import lombok.Setter;

public class CustomerLimitCheckException extends RuntimeException{


}
