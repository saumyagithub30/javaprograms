package upi.exception;

import lombok.Getter;
import lombok.Setter;
import upi.constant.UPICodes;

public class FinalUdioException extends Exception {

    @Getter
    @Setter
    private int code;

    @Getter
    @Setter
    private String message;

    public FinalUdioException()
    {
    }

    public FinalUdioException(String message)
    {
        this.message = message;
    }

    public FinalUdioException(int code, String message)
    {
        this.code = code;
        this.message = message;
    }

    public static FinalUdioException accessDenied()
    {
        return new FinalUdioException(UPICodes.ACCESS_DENIED_ERROR, UPICodes.ACCESS_DENIED_ERROR_MSG);
    }


    public FinalUdioException(Throwable e)
    {
        super(e);
    }

}
