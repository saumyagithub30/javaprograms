package upi.exception;

public class WalletException extends RuntimeException {

}
