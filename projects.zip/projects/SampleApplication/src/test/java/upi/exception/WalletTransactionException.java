package upi.exception;

import lombok.Getter;
import lombok.Setter;

public class WalletTransactionException extends RuntimeException{

}
