package upi.model;

import upi.constant.UPICodes;
import upi.constant.UPIConstants;
import upi.exception.FinalUdioException;
import upi.utils.UpiUtil;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.HashMap;

public class UpiQrStrDecoder {

    private String url;
    private HashMap<String, String> queryParams = new HashMap<String, String>();

    public UpiQrStrDecoder(String url) throws UnsupportedEncodingException, FinalUdioException
    {
        this.url = url;
        if (UpiUtil.isStringEmpty(this.url))
            return;

        StringBuffer tempBuffer = new StringBuffer();
        int incrementor = 0;
        int dataLength = this.url.length();
        while (incrementor < dataLength) {
            char charecterAt = this.url.charAt(incrementor);
            if (charecterAt == '%') {
                tempBuffer.append("<percentage>");
            } else if (charecterAt == '+') {
                tempBuffer.append("<plus>");
            } else {
                tempBuffer.append(charecterAt);
            }
            incrementor++;
        }
        this.url = tempBuffer.toString();
        String urlString = URLDecoder.decode(this.url, "UTF-8");
        urlString = urlString.replaceAll("<percentage>", "%");
        urlString = urlString.replaceAll("<plus>", "+");

        queryParams = new HashMap<String, String>();

        String[] urlPathElements = urlString.split("\\?");
        if (urlPathElements.length < 2)
            throw new FinalUdioException(UPICodes.URL_MALFORMED, UPICodes.URL_MALFORMED_MSG);

        String[] queryParamsStrings = urlPathElements[1].split("&");
        for (String queryParamString : queryParamsStrings)
        {
            String[] keyValuePair = queryParamString.split("=");
            if (keyValuePair.length < 2)
                throw new FinalUdioException(UPICodes.URL_MALFORMED, UPICodes.URL_MALFORMED_MSG);

            queryParams.put(keyValuePair[0].toLowerCase(), keyValuePair[1]);
        }

    }

    public String getPa()
    {
        String pa = queryParams.get("pa");
        return pa;
    }

    public String getPn()
    {
        String pn = queryParams.get("pn");
        return pn;
    }

    public String getInitiationMode()
    {
        String initiationMode = queryParams.get("mode");
        if (UpiUtil.isStringNotEmpty(initiationMode))
            return initiationMode;

        return UPIConstants.DEFAULT_INITIATION_MODE;
    }

    public String getRefCategory()
    {
        String refCategory = queryParams.get("category");
        if (UpiUtil.isStringNotEmpty(refCategory))
            return refCategory;
        return UPIConstants.DEFAULT_REF_CATEGORY;
    }

    public String getPurpose()
    {
        String purpose = queryParams.get("purpose");
        if (UpiUtil.isStringNotEmpty(purpose))
            return purpose;
        return UPIConstants.DEFAULT_PURPOSE;
    }

    public String getUrl()
    {
        return this.url;
    }

    private String getOrgid()
    {
        String orgId = queryParams.get("orgid");
        if (UpiUtil.isStringNotEmpty(orgId))
            return orgId;
        return UPIConstants.DEAFULT_ORG_ID;
    }

    public String getMcc()
    {
        String mcc = queryParams.get("mc");
        if (UpiUtil.isStringNotEmpty(mcc))
            return mcc;
        return null;
    }

    public String getRefId()
    {
        String refId = queryParams.get("tr");
        if (UpiUtil.isStringNotEmpty(refId))
            return refId;
        return null;
    }

    public String getNarration()
    {
        String note = queryParams.get("tn");
        if (UpiUtil.isStringNotEmpty(note)) {
            return note.replaceAll("%20", " ");
        }
        return null;
    }

    public String getRefUrl()
    {
        String refUrl = queryParams.get("url");
        if (UpiUtil.isStringNotEmpty(refUrl))
            return refUrl;
        return null;
    }

    public Double getAmount()
    {
        if (UpiUtil.isStringNotEmpty(queryParams.get("am")))
            return Double.valueOf(queryParams.get("am"));
        return null;
    }

    public String getCurrencyCode()
    {
        String currencyCode = queryParams.get("cu");
        if (UpiUtil.isStringNotEmpty(currencyCode))
            return currencyCode;
        return null;
    }

    public String getMid()
    {
        String mid = queryParams.get("mid");
        if (UpiUtil.isStringNotEmpty(mid))
            return mid;
        return null;
    }

    public String getStoreId()
    {
        String storeId = queryParams.get("msid");
        if (UpiUtil.isStringNotEmpty(storeId))
            return storeId;
        return null;
    }

    public String getTid()
    {
        String tid = queryParams.get("mtid");
        if (UpiUtil.isStringNotEmpty(tid))
            return tid;
        return null;
    }

    public String getCountryCode()
    {
        String countryCode = queryParams.get("cc");
        if (UpiUtil.isStringNotEmpty(countryCode))
            return countryCode;
        return null;
    }

    public String getInvoiceNumber() {
        String invoiceNumber = queryParams.get("invoiceno");
        if (UpiUtil.isStringNotEmpty(invoiceNumber))
            return invoiceNumber;
        return null;
    }

    public String getExpireTime() {
        String expiryTime = queryParams.get("qrexpire");
        if (UpiUtil.isStringNotEmpty(expiryTime))
            return expiryTime;
        return null;
    }


}
