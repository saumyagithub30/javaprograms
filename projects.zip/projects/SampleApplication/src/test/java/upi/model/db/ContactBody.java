package upi.model.db;

import lombok.Data;
import upi.utils.enums.UpiEnums;

@Data
public class ContactBody {

    private String mobileNumber;
    private String name;
    private UpiEnums.UserStatus status;
    private String email;
    private String kycLevel;
    private String profilePicURL;
    private Long consumerId;
}
