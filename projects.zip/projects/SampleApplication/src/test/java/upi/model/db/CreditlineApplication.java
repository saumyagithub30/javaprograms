package upi.model.db;

public class CreditlineApplication {
}
