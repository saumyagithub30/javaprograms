package upi.model.db;

import upi.utils.enums.UpiEnums;

import java.util.List;

public class DebitTransactionObject {
    public DebitTransactionObject(int mccCode, double txnAmount, String txnCode, WalletTransactionType transactionType, List<UpiTransactionBO> specificDetails, String txnCode1, boolean b, UpiEnums.CreditLineProductType creditLineProd, double creditAmount) {
    }
}
