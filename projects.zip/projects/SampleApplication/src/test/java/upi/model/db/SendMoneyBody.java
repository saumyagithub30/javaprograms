package upi.model.db;

import lombok.Data;

import java.util.List;

@Data
public class SendMoneyBody {
    private String message;
    private String txnRefNum;
    private String groupName;
    private List<SendMoneyDetails> sendMoneyDetails;
}
