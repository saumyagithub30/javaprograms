package upi.model.db;

import lombok.Data;

@Data
public class SendMoneyDetails {

    private Double amount;
    private ContactBody contact;
    private Boolean receiveLimitExhausted;
}
