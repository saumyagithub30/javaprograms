package upi.model.db;

public class TransactionSpecificDetail {
}
