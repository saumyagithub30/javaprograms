package upi.model.db;

import lombok.Data;

@Data
public class UpiBlockedUserModel {
    private Long id;
    private String sourceVpa;
    private String destVpa;
    private String destName;
    private String status;
    private String remark;
}
