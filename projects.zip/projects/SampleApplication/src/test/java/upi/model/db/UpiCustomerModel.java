package upi.model.db;

import lombok.Data;
import upi.utils.enums.UpiEnums;

import java.sql.Timestamp;

@Data
public class UpiCustomerModel {

    private Long id;
    private String mobileNumber;
    private Long consumerId;
    private UpiEnums.UpiCustomerStatus status;
    private String accountNumber;
    private Integer wrongMpinCount;
    private Timestamp paymentSuspendedTill;
    private Timestamp registrationTime;
    private Timestamp lastBlockedTime;
    private Timestamp createdDate;
    private Timestamp updatedDate;

}
