package upi.model.db;

import lombok.Data;
import upi.utils.enums.UpiEnums;

import java.util.List;

@Data
public class UpiRmsLimitModel {
    private List<String> payerAddresses;
    private List<String> payeeAddresses;

    private UpiEnums.UpiCustomerType customerType;
    private Double amount;
}
