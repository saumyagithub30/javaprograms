package upi.model.db;

import lombok.Data;

@Data
public class UpiTransactionBO {

    private double amount;
    private String status;
    private UpiTransactionModel upiTransactionModel;
}
