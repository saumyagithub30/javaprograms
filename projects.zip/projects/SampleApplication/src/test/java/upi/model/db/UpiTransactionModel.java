package upi.model.db;

import lombok.Builder;
import lombok.Data;
import upi.utils.enums.UpiEnums;

import java.sql.Timestamp;

@Data
public class UpiTransactionModel {

    private Long id;
    private String payerAddress;
    private String payeeAddress;
    private String payeeMobileNumber;
    private String payerMobileNumber;
    private String payeeAccountNumber;
    private String payerAccountNumber;
    private String payeeAccountType;
    private String payerAccountType;
    private String payeeIfsc;
    private String payerIfsc;
    private String payeeName;
    private String payerName;
    private UpiEnums.UpiCustomerType payerType;
    private UpiEnums.UpiCustomerType payeeType;
    private String payeeMcc;
    private String payerMcc;
    private String txnCode;
    private String txnRefCodeNpci;
    private String walletTxnCode;
    private String narration;
    private String refId;
    private UpiEnums.PaymentType paymentType;
    private UpiEnums.UpiTransactionStatus status;
    private UpiEnums.UpiConfirmationSubType subtype;
    private UpiEnums.UpiInitiationMode initmode;
    private UpiEnums.UpiTransactionPurpose purpose;
    private UpiEnums.UpiTxnType txnType;
    private UpiEnums.Mode txnMode;
    private Boolean isDebitReversal;
    private UpiEnums.UpiTransactionInitiator initiatedBy;
    private Double amount;
    private Double creditAmount;
    private Double lat;
    private Double longitude;
    private String ipAddress;
    private String appId;
    private String deviceId;
    private String os;
    private String location;
    private Timestamp webhookTimestamp;
    private Timestamp transactionTimestamp;
    private Timestamp initiatedTimestamp;
    private Timestamp expiryTimestamp;
    private Timestamp collectTimestamp;
    private String code;
    private String subcode;
    private String subresult;
    private String qrUrl;
    private UpiEnums.QRType qrType;
    private Timestamp createdDate;
    private Timestamp updatedDate;
    private String payeeReversalCode;
    private String payerReversalCode;
    private String providerStatus;
    private String latency;
    private String category;
    private String invoiceurl;
    private UpiEnums.CollectType collectRequestStatus;

}
