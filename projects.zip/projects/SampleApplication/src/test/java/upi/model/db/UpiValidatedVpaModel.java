package upi.model.db;

import lombok.Data;
import upi.utils.enums.UpiEnums;

import java.sql.Timestamp;

@Data
public class UpiValidatedVpaModel {

    private Long id;
    private UpiEnums.ValidationSource validationSource;
    private String validatorAddress;
    private String validatedAddress;
    private UpiEnums.UpiCustomerType validatedType;
    private String validatedName;
    private UpiEnums.ValidateVpaStatus status;
    private String txnId;
    private String validatedIfsc;
    private String validatedIin;
    private String mcc;
    private String merchantSubCode;
    private String merchantMid;
    private String merchantSid;
    private String merchantTid;
    private String merchantType;
    private String merchantGenre;
    private String merchantOnboardingType;
    private String merchantBrandName;
    private String merchantLegalName;
    private String merchantFranchiseName;
    private String merchantOwnershipType;
    private Boolean isActive;
    private Double lat;
    private Double longitude;
    private String ipAddress;
    private String appId;
    private String os;
    private Timestamp webhookTimestamp;
    private Timestamp validationTimestamp;
    private Timestamp expiryTimestamp;
    private String responseCode;
    private String errorCode;
    private String errorReason;
    private Timestamp createdDate;
    private Timestamp updatedDate;
}
