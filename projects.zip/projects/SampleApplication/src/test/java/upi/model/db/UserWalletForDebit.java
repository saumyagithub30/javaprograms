package upi.model.db;

import lombok.Data;

@Data
public class UserWalletForDebit {
    private Double balance;
}
