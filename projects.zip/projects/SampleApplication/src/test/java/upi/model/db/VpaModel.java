package upi.model.db;

import lombok.Builder;
import lombok.Data;
import upi.utils.enums.UpiEnums;

import java.sql.Timestamp;

@Data
@Builder
public class VpaModel {

    private Long id;
    private Long consumerId;
    private String mobileNumber;
    private String name;
    private String address;
    private String mpin;
    private Boolean isDefault;
    private String accountNumber;
    private Integer registrationTryCount;
    private Integer unlinkTryCount;
    private UpiEnums.VpaRegistrationStatus registrationStatus;
    private UpiEnums.VpaStatus status;
    private UpiEnums.UpiProvider provider;
    private UpiEnums.VpaRegistrationSource source;
    private String responseCode;
    private String errorCode;
    private String errorReason;
    private String appId;
    private Timestamp registrationTime;
    private Timestamp lastActiveTime;
    private Timestamp lastUnlinkTime;
    private Timestamp createdDate;
    private Timestamp updatedDate;
}
