package upi.model.db;

import lombok.Data;

@Data
public class WalletTransactionType {

    private Boolean dofEnabled;
}
