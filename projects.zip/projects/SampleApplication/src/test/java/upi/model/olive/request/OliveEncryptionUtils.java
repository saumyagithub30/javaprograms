package upi.model.olive.request;

public class OliveEncryptionUtils {
    public static String encryptRequest(String requestBodyStr) {
        return null;
    }

    public static String decryptResponse(String data) {
        return null;
    }
}
