package upi.model.olive.request;

import lombok.Data;

@Data
public class OliveFinalRequest {

    private String txnid;
    private String channelid;
    private String payload;
}
