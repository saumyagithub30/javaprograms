package upi.model.olive.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class OliveTxnRequest {
    private String trantype;
    private String txnid;
    private String rrn;
    private String orderid;
    private String amount;
    private String initmode;
    private String purpose;
    private String remarks;
    private String payrefnumber;
    private String appid;
    private String refurl;
    private DeviceInfo device;
    private PayerInfo payerinfo;
    private PayeeInfo payeeinfo;
    private String expirydatetime;

    @JsonIgnoreProperties(ignoreUnknown = true)
    @Data
    public class DeviceInfo {
        private String appid;
        private String capability;
        private String id;
        private String ip;
        private String location;
        private String mobile;
        private String os;
        private String type;
        private String geocode;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    @Data
    public class PayerInfo {
        private String name;
        private String accountnumber;
        private String vpa;
        private String mcc;
        private String mobile;
        private String accounttype;
        private String ifsc;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    @Data
    public class PayeeInfo {
        private String name;
        private String accountnumber;
        private String vpa;
        private String mcc;
        private String mobile;
        private String accounttype;
        private String ifsc;
    }
}
