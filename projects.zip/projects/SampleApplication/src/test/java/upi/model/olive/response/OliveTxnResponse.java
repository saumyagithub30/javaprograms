package upi.model.olive.response;

import lombok.Data;

@Data
public class OliveTxnResponse {

    private String data;
    private String code;
    private String subcode;
    private String result;
    private String subresult;
    private String latency;
}
