package upi.model.olive.response;

public class ProviderResponse<T> {

    private T response;

    public void setResponse(T response) {
    }

    public void setRestException(String restException) {

    }

    public Object getResponse()
    {
        return response;
    }

}
