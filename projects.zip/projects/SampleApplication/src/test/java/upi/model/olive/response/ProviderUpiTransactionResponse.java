package upi.model.olive.response;

import lombok.Data;

@Data
public class ProviderUpiTransactionResponse {
    private boolean success;
    private String code;
    private String subcode;
    private String subresult;
    private boolean shouldRetry = Boolean.FALSE;
    private String txnId;
    private String rrn;
    private String latency;
}
