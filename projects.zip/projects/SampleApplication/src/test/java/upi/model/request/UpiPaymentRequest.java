package upi.model.request;

import lombok.Builder;
import lombok.Data;

import upi.model.UpiQrStrDecoder;
import upi.utils.enums.UpiEnums;

@Data
@Builder
public class UpiPaymentRequest {

    private Boolean useCreditLimit = false;
    private String payeeAddress;
    private UpiEnums.PaymentType paymentType;
    private Double amount;
    private String txnCode;
    private String note;
    private String qrUrl;
    private String mpin;
    private String txnType;

    private UpiQrStrDecoder urlDecoder;
}
