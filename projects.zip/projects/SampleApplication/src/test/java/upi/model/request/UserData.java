package upi.model.request;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class UserData {

    private Long consumerId;
    private String fullName;
    private String mobileNumber;
    private Long productId;
    private String email;
    private String userKycLevel;
    private Boolean isLoanUser;
    private Boolean isWalletUser;

}
