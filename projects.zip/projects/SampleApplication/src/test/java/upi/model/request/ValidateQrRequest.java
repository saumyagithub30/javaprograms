package upi.model.request;

import lombok.Data;

@Data
public class ValidateQrRequest
{
    private String qrString;
}
