package upi.model.request;

import lombok.Data;

@Data
public class ValidateVpaRequest {
    private String vpa;
    private String validationSource;
}
