package upi.model.response;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;

@Data
public class UpiBalanceInfoResponse {

    private Boolean isDofEnabled = false;
    private Boolean creditLimitExists = false;
    private Boolean canUseCreditLimit = false;

    @JsonIgnore
    private Double walletBalance;
}
