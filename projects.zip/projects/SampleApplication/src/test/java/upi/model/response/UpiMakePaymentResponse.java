package upi.model.response;

import lombok.Builder;
import lombok.Data;

@Data
public class UpiMakePaymentResponse {

    private String txnCode;

}
