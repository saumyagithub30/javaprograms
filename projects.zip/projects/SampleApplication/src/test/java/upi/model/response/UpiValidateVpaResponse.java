package upi.model.response;

public class UpiValidateVpaResponse {
    private String status;
    private String name;
    private String type;
    private UpiBalanceInfoResponse debitInfoResponse;
}
