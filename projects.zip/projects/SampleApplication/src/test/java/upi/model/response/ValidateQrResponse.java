package upi.model.response;

import lombok.Data;

@Data
public class ValidateQrResponse {

    private Boolean canTransact = true;
    private Double amount;
    private String payeeName;
    private String payeeAddress;
    private String note;
    private UpiValidateVpaResponse validateVpaResponse;
}
