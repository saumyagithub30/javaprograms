package upi.properties;

public class UpiConfigProperties {
    public static final String UPI_DISABLE_P2P_TRANSACTIONS = "UPI_DISABLE_P2P_TRANSACTIONS";
    public static final String UPI_ENABLE_WALLET_TO_WALLET_PAY_FOR_DHANI_USERS = "UPI_ENABLE_WALLET_TO_WALLET_PAY_FOR_DHANI_USERS";
    public static final String UPI_ENABLE = "UPI_ENABLE";
}
