package upi.service;

import upi.exception.FinalUdioException;

public interface ConfigService {

    public Boolean getBoolean(String name) throws FinalUdioException;
}
