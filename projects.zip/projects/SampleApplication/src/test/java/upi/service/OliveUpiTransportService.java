package upi.service;

import upi.model.olive.request.OliveTxnRequest;
import upi.model.olive.response.OliveTxnResponse;
import upi.model.olive.response.ProviderResponse;

public interface OliveUpiTransportService {

    ProviderResponse<OliveTxnResponse> sendCollectMoney(OliveTxnRequest oliveTxnRequest);
}
