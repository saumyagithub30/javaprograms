package upi.service;

import upi.exception.FinalUdioException;
import upi.model.db.UpiCustomerModel;
import upi.model.db.UpiTransactionModel;
import upi.model.olive.response.ProviderUpiTransactionResponse;
import upi.model.request.UpiPaymentRequest;

public interface ProviderService {

    ProviderUpiTransactionResponse makePayment(UpiTransactionModel upiTransactionModel, UpiPaymentRequest upiPaymentRequest, UpiCustomerModel upiCustomerModel) throws FinalUdioException;
}
