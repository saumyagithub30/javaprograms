package upi.service;

import upi.exception.FinalUdioException;
import upi.model.db.SendMoneyBody;
import upi.model.request.UserData;
import upi.utils.enums.UpiEnums;

import java.util.Map;

public interface RequestSendMoneyService {
    public Map<String,Object> sendMoney(SendMoneyBody sendMoneyBody, UserData userData, UpiEnums.Source source) throws FinalUdioException;
}
