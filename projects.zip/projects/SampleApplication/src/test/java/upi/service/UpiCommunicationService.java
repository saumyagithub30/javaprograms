package upi.service;

public class UpiCommunicationService {
    public void sendPaymentFailureSms(String txnCode) {
    }

    public void sendRMSLimitFailedSMS(String mobileNumber, String message) {
    }
}
