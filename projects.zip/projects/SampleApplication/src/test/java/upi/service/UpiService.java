package upi.service;

import java.io.UnsupportedEncodingException;

import upi.model.request.ValidateQrRequest;
import upi.model.response.UpiMakePaymentResponse;
import upi.model.request.UpiPaymentRequest;
import upi.model.request.UserData;
import upi.exception.FinalUdioException;
import upi.model.response.ValidateQrResponse;

public interface UpiService {

    UpiMakePaymentResponse makePayment(UserData userData, UpiPaymentRequest upiPaymentRequest) throws FinalUdioException, UnsupportedEncodingException;

    ValidateQrResponse validateQrString(UserData userData, ValidateQrRequest validateQrRequest, boolean validateVpa) throws FinalUdioException, UnsupportedEncodingException;
}
