package upi.service.impl;

import upi.model.db.DebitTransactionBO;
import upi.model.db.DebitTransactionObject;
import upi.model.db.UserWalletForDebit;

import java.util.List;

public class BridgeWalletServiceImpl {

    public List<UserWalletForDebit> getWalletsByMccCode(int mccCode, Long consumerId) {
        return null;
    }

    public DebitTransactionBO debit(DebitTransactionObject debitTransactionObject) {
        return null;
    }
}
