package upi.service.impl;

import upi.model.db.UpiRmsLimitModel;
import upi.model.db.WalletTransactionType;
import upi.model.request.UserData;

public class CustomerLimitServiceImpl {
    public void rmsChecks(WalletTransactionType transactionType, UserData userData, double txnAmount, UpiRmsLimitModel upiRmsLimitModel) {
    }
}
