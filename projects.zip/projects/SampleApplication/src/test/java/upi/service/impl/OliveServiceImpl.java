package upi.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import upi.exception.FinalUdioException;
import upi.model.db.UpiCustomerModel;
import upi.model.db.UpiTransactionModel;
import upi.model.olive.request.OliveTxnRequest;
import upi.model.olive.response.OliveTxnResponse;
import upi.model.olive.response.ProviderResponse;
import upi.model.olive.response.ProviderUpiTransactionResponse;
import upi.model.request.UpiPaymentRequest;
import upi.service.OliveUpiTransportService;
import upi.service.ProviderService;
import upi.utils.OliveConverterUtils;

public class OliveServiceImpl implements ProviderService {

    @Autowired
    private OliveUpiTransportService oliveUpiTransportService;
    @Override
    public ProviderUpiTransactionResponse makePayment(UpiTransactionModel upiTransactionModel, UpiPaymentRequest upiPaymentRequest, UpiCustomerModel upiCustomerModel) throws FinalUdioException
    {
        OliveTxnRequest oliveTxnRequest = OliveConverterUtils.prepareMakePaymentRequest(upiTransactionModel, upiPaymentRequest, upiCustomerModel);
        ProviderResponse<OliveTxnResponse> oliveResponse = oliveUpiTransportService.sendCollectMoney(oliveTxnRequest);
        ProviderUpiTransactionResponse transactionResponse = OliveConverterUtils.prepareUpiTransactionResponse(oliveResponse);
        return transactionResponse;
    }
}
