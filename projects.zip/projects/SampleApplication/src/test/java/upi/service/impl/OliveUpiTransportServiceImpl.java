package upi.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.http.*;
import org.springframework.web.client.AsyncRestTemplate;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;
import upi.constant.UrlConstant;
import upi.model.olive.request.OliveEncryptionUtils;
import upi.model.olive.request.OliveFinalRequest;
import upi.model.olive.request.OliveTxnRequest;
import upi.model.olive.response.OliveTxnResponse;
import upi.model.olive.response.ProviderResponse;
import upi.service.OliveUpiTransportService;
import upi.utils.UpiUtil;

import static com.sun.xml.internal.ws.spi.db.BindingContextFactory.LOGGER;

public class OliveUpiTransportServiceImpl implements OliveUpiTransportService {

    private RestTemplate restTemplate;

    private <T, V> ProviderResponse<T> restPostRequest(String url, String txnId, V request, Class<T> responseClass)
    {
        ProviderResponse<T> providerResponse = new ProviderResponse<T>();
        T response = null;
        String restException = null;

        long startTime = System.currentTimeMillis();
        try
        {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);

            ObjectMapper mapper = new ObjectMapper();
            String requestBodyStr = mapper.writeValueAsString(request);

            String encryptedPayload = OliveEncryptionUtils.encryptRequest(requestBodyStr);
            OliveFinalRequest finalRequest = new OliveFinalRequest();
            finalRequest.setTxnid(txnId);
            finalRequest.setPayload(encryptedPayload);

            url = UriComponentsBuilder.fromUriString(url).queryParam("channelid", finalRequest.getChannelid())
                    .queryParam("txnid", finalRequest.getTxnid()).build().toUriString();

            LOGGER.info("Call to Olive: " + url + "\nPayload: " + requestBodyStr + "\nEncrypted Request: " + mapper.writeValueAsString(finalRequest));

            HttpEntity<OliveFinalRequest> httpEntity = new HttpEntity<OliveFinalRequest>(finalRequest, headers);

            ResponseEntity<T> result = restTemplate.exchange(url, HttpMethod.POST, httpEntity, responseClass);
            response = result.getBody();
            LOGGER.info("Encrypted Response: " + response.toString());

            LOGGER.info("Response from Olive: " + ", RESPONSE_TIME(Milis): " + (System.currentTimeMillis() - startTime));

            providerResponse.setResponse(response);
            return providerResponse;
        }
        catch (ResourceAccessException rae)
        {
            LOGGER.info("ResourceAccessException in Olive API : ");
            restException = "RestException: " + rae.getMessage();
        }
        catch (Exception e)
        {
            LOGGER.info("Exception in Olive API : ");
            restException = "RestException: " + e.getMessage();
        }
        providerResponse.setResponse(response);
        providerResponse.setRestException(restException);

        return providerResponse;
    }

    @Override
    public ProviderResponse<OliveTxnResponse> sendCollectMoney(OliveTxnRequest oliveTxnRequest) {
        String url = UrlConstant.OLIVE_PAY_URI;
        ProviderResponse<OliveTxnResponse> response = restPostRequest(url, oliveTxnRequest.getTxnid(), oliveTxnRequest, OliveTxnResponse.class);

        if (response.getResponse() != null)
        {
            OliveTxnResponse apiResponse = (OliveTxnResponse) response.getResponse();

            if (UpiUtil.isStringNotEmpty(apiResponse.getData()))
            {
                String decryptedResponse = null;
                try
                {
                    decryptedResponse = OliveEncryptionUtils.decryptResponse(apiResponse.getData());
                    LOGGER.info("Decrypted response" + decryptedResponse);
                }
                catch (Exception e)
                {
                    LOGGER.info("Error while decrypting olive response" + oliveTxnRequest.getTxnid());
                }

            }
        }

        return response;
    }
}
