package upi.service.impl;

import java.io.UnsupportedEncodingException;
import java.text.MessageFormat;
import java.util.*;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import upi.constant.UPICodes;
import upi.constant.UPIConstants;
import upi.dao.*;
import upi.exception.CustomerLimitCheckException;
import upi.exception.FinalUdioException;
import upi.exception.WalletException;
import upi.exception.WalletTransactionException;
import upi.model.UpiQrStrDecoder;
import upi.model.db.*;
import upi.model.olive.response.ProviderUpiTransactionResponse;
import upi.model.request.UpiPaymentRequest;
import upi.model.request.UserData;
import upi.model.request.ValidateQrRequest;
import upi.model.request.ValidateVpaRequest;
import upi.model.response.UpiMakePaymentResponse;
import upi.model.response.UpiValidateVpaResponse;
import upi.model.response.ValidateQrResponse;
import upi.properties.UpiConfigProperties;
import upi.service.*;
import upi.utils.UpiUtil;
import upi.utils.enums.UpiEnums;
import upi.utils.validator.UpiValidator;
import upi.websecurity.SecurityConfig;

import static com.sun.xml.internal.ws.spi.db.BindingContextFactory.LOGGER;

public class UpiServiceImpl implements UpiService {

    @Autowired
    private VpaDaoWrapper vpaDao;

    @Autowired
    private UpiCustomerDeviceBindingDaoWrapper upiCustomerDeviceBindingDao;

    @Autowired
    private UpiTransactionDaoWrapper upiTransactionDao;

    @Autowired
    private UpiCustomerDaoWrapper upiCustomerDao;

    @Autowired
    private UpiUtil upiUtils;

    @Autowired
    private UpiBlockedUserDaoWrapper upiBlockedUserDao;

    @Autowired
    private ConfigService configService;

    @Autowired
    private RequestSendMoneyService requestSendMoneyService;

    @Autowired
    private WalletTransactionTypeDaoWrapper walletTransactionTypeDao;

    @Autowired
    private CustomerLimitServiceImpl customerLimitService;

    @Autowired
    private BridgeWalletServiceImpl bridgedWalletService;

    @Autowired
    private ProviderService oliveProviderService;

    @Autowired
    private UpiCommunicationService upiCommunicationService;

    @Override
    public UpiMakePaymentResponse makePayment(UserData userData, UpiPaymentRequest upiPaymentRequest) throws FinalUdioException, UnsupportedEncodingException {
        UpiValidator.validateUpiPayment(upiPaymentRequest);
        String mobileNumber = userData.getMobileNumber();

        isUpiTransactionAllowed(mobileNumber);

        VpaModel vpaModel = vpaDao.getActiveVpaByMobileNumber(mobileNumber);
        if (Objects.isNull(vpaModel))
            throw new FinalUdioException(UPICodes.NO_ACTIVE_VPA, UPICodes.NO_ACTIVE_VPA_MSG);

        checkPaymentEnabled(upiPaymentRequest);
        checkTimeDiffBetweenLastPayment(vpaModel, "pay");

        if (!isDeviceRegistered(mobileNumber, SecurityConfig.getDeviceId()))
            throw new FinalUdioException(UPICodes.DEVICE_NOT_REGISTERED, UPICodes.DEVICE_NOT_REGISTERED_MSG);

        if (upiPaymentRequest.getPaymentType().equals(UpiEnums.PaymentType.repayment))
        {
            UpiTransactionModel previousTxn = upiTransactionDao.getTransactionByCodeAndTxnType(upiPaymentRequest.getTxnCode(), UpiEnums.UpiTxnType.valueOf(upiPaymentRequest.getTxnType()));
            if (Objects.isNull(previousTxn))
                throw new FinalUdioException(UPICodes.REF_TXN_NOT_FOUND, UPICodes.REF_TXN_NOT_FOUND_MSG);

            if (UpiUtil.isStringNotEmpty(previousTxn.getQrUrl()) && previousTxn.getQrType() == UpiEnums.QRType.dynamicQR) {
                throw new FinalUdioException(UPICodes.DYNAMIC_QR_REPAYMENT, UPICodes.DYNAMIC_QR_REPAYMENT_MSG);
            }

            upiPaymentRequest.setPayeeAddress(previousTxn.getPayeeAddress());
            if (previousTxn.getPaymentType() == UpiEnums.PaymentType.scan_and_pay) {
                if (UpiUtil.isStringNotEmpty(previousTxn.getQrUrl())) {
                    upiPaymentRequest.setUrlDecoder(new UpiQrStrDecoder(previousTxn.getQrUrl()));
                }
            }
        }

        if (upiPaymentRequest.getPaymentType().equals(UpiEnums.PaymentType.scan_and_pay))
        {
            ValidateQrRequest request = new ValidateQrRequest();
            request.setQrString(upiPaymentRequest.getQrUrl());

            validateQrString(userData, request, false);

            UpiQrStrDecoder urlDecoder = upiPaymentRequest.getUrlDecoder();

            if (Objects.nonNull(urlDecoder.getAmount()) && !upiPaymentRequest.getAmount().equals(urlDecoder.getAmount()))
                throw new FinalUdioException(UPICodes.AMOUNT_MISMATCH_FOR_DYNAMIC_QR, UPICodes.AMOUNT_MISMATCH_FOR_DYNAMIC_QR_MSG);

            upiPaymentRequest.setPayeeAddress(upiPaymentRequest.getUrlDecoder().getPa());
        }

        if (UpiUtil.isStringEmpty(upiPaymentRequest.getNote()))
            upiPaymentRequest.setNote(UPIConstants.UPI_DEFAULT_NOTE);

        UpiCustomerModel upiCustomerModel = upiCustomerDao.getActiveCustomerModelByMobileNumber(mobileNumber);

        if (Objects.isNull(upiCustomerModel))
            throw new FinalUdioException(UPICodes.NOT_AN_ACTIVE_UPI_CUSTOMER, UPICodes.NOT_AN_ACTIVE_UPI_CUSTOMER_MSG);

        if (Objects.nonNull(upiCustomerModel.getPaymentSuspendedTill()) && upiCustomerModel.getPaymentSuspendedTill().after(UpiUtil.getNow()))
        {
            int diff = (int) Math.ceil((upiCustomerModel.getPaymentSuspendedTill().getTime() - UpiUtil.getNow().getTime()) / (1000 * 60));
            throw new FinalUdioException(UPICodes.PAYMENT_SUSPENDED_TILL_ERROR, MessageFormat.format(UPICodes.PAYMENT_SUSPENDED_TILL_ERROR_MSG, diff));
        }

        if (!UpiUtil.isPinMatching(upiPaymentRequest.getMpin(), upiCustomerModel.getMobileNumber(), vpaModel.getMpin()))
        {
            updateFailedMpin(upiCustomerModel, vpaModel);
            throw new FinalUdioException(UPICodes.INVALID_MPIN, UPICodes.INVALID_MPIN_MSG);
        }
        else
        {
            upiCustomerModel.setWrongMpinCount(0);
            upiCustomerModel.setPaymentSuspendedTill(null);
            upiCustomerDao.updateById(upiCustomerModel);
        }

        String payerAddress = vpaModel.getAddress();

        if (upiPaymentRequest.getPayeeAddress().equalsIgnoreCase(payerAddress))
            throw new FinalUdioException(UPICodes.PAYER_PAYEE_SAME, UPICodes.PAYER_PAYEE_SAME_MSG);

        UpiValidatedVpaModel validatedVpaModel = upiUtils.getActiveValidateVpaModel(upiPaymentRequest.getPayeeAddress());
        if (Objects.isNull(validatedVpaModel))
            throw new FinalUdioException(UPICodes.VPA_NOT_VALIDATED, UPICodes.VPA_NOT_VALIDATED_MSG);

        List<UpiBlockedUserModel> blockedUserList = upiBlockedUserDao.getBlockedUsers(vpaModel.getAddress(), UpiEnums.UpiBlockedUserType.source.toString());
        if (blockedUserList != null || blockedUserList.size() != 0) {
            for (UpiBlockedUserModel b : blockedUserList)
            {
                if(b.getDestVpa().equals(upiPaymentRequest.getPayeeAddress())) {
                    throw new FinalUdioException(UPICodes.VPA_BLOCK, UPICodes.VPA_BLOCK_MSG);
                }
            }
        }

        if(configService.getBoolean(UpiConfigProperties.UPI_DISABLE_P2P_TRANSACTIONS))
        {
            if(UpiEnums.UpiCustomerType.customer.equals(validatedVpaModel.getValidatedType()))
            {
                throw new FinalUdioException(UPICodes.UPI_P2P_TRANSACTIONS_NOT_ALLOWED, UPICodes.UPI_P2P_TRANSACTIONS_NOT_ALLOWED_MSG);
            }
        }

        UpiTransactionModel upiTransactionModel = null;

        try
        {

            if(configService.getBoolean(UpiConfigProperties.UPI_ENABLE_WALLET_TO_WALLET_PAY_FOR_DHANI_USERS))
            {
                if(UpiUtil.isValidDhaniUpiAddress(upiPaymentRequest.getPayeeAddress()))
                {
                    VpaModel payeeVpaModel = vpaDao.getByAddress(upiPaymentRequest.getPayeeAddress());
                    if(Objects.isNull(payeeVpaModel) || !	payeeVpaModel.getStatus().equals(UpiEnums.VpaStatus.active))
                        throw new FinalUdioException(UPICodes.NO_ACTIVE_VPA, UPICodes.NO_ACTIVE_VPA_MSG);

                    SendMoneyBody sendMoneyBody = new SendMoneyBody();
                    sendMoneyBody.setMessage("Upi transaction: " + (StringUtils.isEmpty(upiPaymentRequest.getNote())?"":upiPaymentRequest.getNote()));
                    SendMoneyDetails sendMoneyDetail = new SendMoneyDetails();
                    sendMoneyDetail.setAmount(upiPaymentRequest.getAmount());
                    ContactBody contactBody = new ContactBody();
                    contactBody.setMobileNumber(payeeVpaModel.getMobileNumber());
                    sendMoneyDetail.setContact(contactBody);
                    List<SendMoneyDetails> sendMoneyDetails = new ArrayList<>();
                    sendMoneyDetails.add(sendMoneyDetail);
                    sendMoneyBody.setSendMoneyDetails(sendMoneyDetails);
                    sendMoneyBody.setTxnRefNum(upiUtils.generateOliveUpiTxnCode());
                    Map<String, Object> response = requestSendMoneyService
                            .sendMoney(sendMoneyBody, userData, UpiEnums.Source.upi);
                    UpiMakePaymentResponse upiMakePaymentResponse = new UpiMakePaymentResponse();
                    upiMakePaymentResponse.setTxnCode(String.valueOf(response.get("txnRefNum")));
                    return upiMakePaymentResponse;
                }
            }

            double txnAmount = upiPaymentRequest.getAmount();

            WalletTransactionType transactionType = walletTransactionTypeDao.getWalletTransactionTypeByCode(UPIConstants.UPI_PAYMENT_TXN_TYPE_CODE);

            UpiRmsLimitModel upiRmsLimitModel = new UpiRmsLimitModel();
            List<VpaModel> vpaModels = vpaDao.getRegisteredVpaModelsByMobileNumber(mobileNumber);
            List<String> vpaAddresses = vpaModels.stream().map(x -> x.getAddress()).collect(Collectors.toList());
            upiRmsLimitModel.setPayerAddresses(vpaAddresses);
            upiRmsLimitModel.setPayeeAddresses(Arrays.asList(upiPaymentRequest.getPayeeAddress()));

            upiRmsLimitModel.setCustomerType(validatedVpaModel.getValidatedType());
            upiRmsLimitModel.setAmount(upiPaymentRequest.getAmount());

            customerLimitService.rmsChecks(transactionType, userData, txnAmount, upiRmsLimitModel);

            int mccCode = UPIConstants.CUSTOMER_MCC_CODE;

            UserWalletForDebit userWalletForDebit = new UserWalletForDebit();
            double walletBalance = userWalletForDebit.getBalance();

            double creditAmount = 0.0;
            boolean useCredit = false;
            UpiEnums.CreditLineProductType creditLineProd = null;
            if (walletBalance >= txnAmount && upiPaymentRequest.getUseCreditLimit())
                throw new FinalUdioException(UPICodes.CANNOT_USE_DOF, UPICodes.CANNOT_USE_DOF_MSG);

            if (walletBalance < txnAmount && upiPaymentRequest.getUseCreditLimit())
            {
                if (!transactionType.getDofEnabled())
                    throw new FinalUdioException(UPICodes.DOF_NOT_ENABLED, UPICodes.DOF_NOT_ENABLED_MSG);
                else
                {
                    boolean creditUsageAllowed = false;
                    CreditlineApplication creditApplication = upiCustomerDao.getCreditlineApplicationByMobile(UpiEnums.CreditLineProductType.supersaver.name(),
                            userData.getMobileNumber());
                    boolean isValidApp = UpiUtil.isValidCreditlineApplication(creditApplication);
                    if (isValidApp)
                    {
                        creditUsageAllowed = true;
                        creditAmount = txnAmount - walletBalance;
                        useCredit = true;
                    }

                    creditLineProd = Boolean.TRUE.equals(useCredit) ? UpiEnums.CreditLineProductType.supersaver : null;

                    if (creditUsageAllowed && UpiEnums.CreditLineProductType.supersaver.equals(creditLineProd))
                    {
                        if (!isCreditlineTransactionAllowed(creditApplication, creditAmount))
                        {
                            throw new FinalUdioException(UPICodes.CANNOT_USE_DOF, UPICodes.CANNOT_USE_DOF_MSG);
                        }
                    }
                }
            }

            String txnCode = String.valueOf(UpiUtil.generateRandomAlphanumericString(16));

            upiTransactionModel = upiUtils.genUpiTransaction(vpaModel, validatedVpaModel, upiPaymentRequest, creditAmount, upiCustomerModel, upiUtils);
            LOGGER.info("Transaction Details : " + upiTransactionModel.toString());
            upiTransactionDao.save(upiTransactionModel);

            if (upiTransactionModel.getExpiryTimestamp()!=null && UpiUtil.getNow().after(upiTransactionModel.getExpiryTimestamp())) {
                upiTransactionModel.setStatus(UpiEnums.UpiTransactionStatus.expired);
                upiTransactionDao.updateById(upiTransactionModel);
            } else {
                List<UpiTransactionBO> specificDetails = new ArrayList<>(1);
                UpiTransactionBO upiTransactionBO = new UpiTransactionBO();
                upiTransactionBO.setUpiTransactionModel(upiTransactionModel);
                upiTransactionBO.setAmount(txnAmount);
                specificDetails.add(upiTransactionBO);

                DebitTransactionObject debitTransactionObject = new DebitTransactionObject(mccCode, txnAmount, upiTransactionModel.getTxnCode(), transactionType, specificDetails,
                        txnCode, true, creditLineProd, creditAmount);
                DebitTransactionBO debitInfo = bridgedWalletService.debit(debitTransactionObject);

                if (upiTransactionModel.getStatus() == UpiEnums.UpiTransactionStatus.wallet_debited)
                {
                    Long startTime = System.currentTimeMillis();

                    ProviderUpiTransactionResponse response = oliveProviderService.makePayment(upiTransactionModel, upiPaymentRequest, upiCustomerModel);

                    Long endTime = System.currentTimeMillis();
                    upiTransactionModel.setLatency(String.valueOf(endTime-startTime));
                    upiTransactionModel.setStatus(UpiEnums.UpiTransactionStatus.waiting_for_webhook);
                    upiTransactionModel.setCode(response.getCode());
                    upiTransactionModel.setSubcode(response.getSubcode());
                    upiTransactionModel.setSubresult(response.getSubresult());
                    if (UpiEnums.OliveApiResponseStatus.SUCCESS.getCode().equals(response.getCode()))
                    {
                        upiTransactionModel.setTxnRefCodeNpci(response.getRrn());
                    }
                    else if (UpiEnums.OliveApiResponseStatus.TIMEOUT.getCode().equals(response.getCode()))
                    {
                        upiTransactionModel.setStatus(UpiEnums.UpiTransactionStatus.pending);
                    }
                    else
                    {
                        upiTransactionModel.setStatus(UpiEnums.UpiTransactionStatus.failed);
                        upiCommunicationService.sendPaymentFailureSms(upiTransactionModel.getTxnCode());
                    }
                }
                else
                {
                    upiTransactionModel.setStatus(UpiEnums.UpiTransactionStatus.failed);
                    upiTransactionModel.setSubresult(UPIConstants.UPI_WALLET_DEBIT_FAILED);
                }
                upiTransactionDao.updateById(upiTransactionModel);
            }
        }
        catch (WalletException walletException)
        {
            throw new FinalUdioException(walletException.getMessage());
        }
        catch (CustomerLimitCheckException clce)
        {
            upiCommunicationService.sendRMSLimitFailedSMS(userData.getMobileNumber(), clce.getMessage());
            throw new FinalUdioException(clce.getMessage());
        }
        catch (WalletTransactionException wte)
        {
            throw new FinalUdioException(wte.getMessage());
        }

        UpiMakePaymentResponse response = new UpiMakePaymentResponse();
        response.setTxnCode(upiTransactionModel.getTxnCode());

        return response;
    }

    private boolean isCreditlineTransactionAllowed(CreditlineApplication creditApplication, double creditAmount) {
        return false;
    }

    private void updateFailedMpin(UpiCustomerModel upiCustomerModel, VpaModel vpaModel) {
    }

    private void checkTimeDiffBetweenLastPayment(VpaModel vpaModel, String pay) {
    }

    private void checkPaymentEnabled(UpiPaymentRequest upiPaymentRequest) {
    }

    private Boolean isUpiTransactionAllowed(String mobileNumber)
    {
        try
        {
            if (!configService.getBoolean(UpiConfigProperties.UPI_ENABLE))
                return Boolean.FALSE;

            if (!isUPIEnablebForUser(mobileNumber))
                return Boolean.FALSE;

            return Boolean.TRUE;
        }
        catch (Exception e)
        {
            LOGGER.info("Error while getting upi unable status for mobile: " + mobileNumber);
        }

        return Boolean.FALSE;

    }

    private Boolean isUPIEnablebForUser(String mobileNumber)
    {
        return Boolean.TRUE;
    }

    public boolean isDeviceRegistered(String mobileNumber, String deviceId)
    {
        return upiCustomerDeviceBindingDao.isDeviceBinded(mobileNumber, deviceId);
    }

    @Override
    public ValidateQrResponse validateQrString(UserData userData, ValidateQrRequest validateQrRequest, boolean validateVpa) throws FinalUdioException, UnsupportedEncodingException
    {
        UpiValidator.validateQrRequest(validateQrRequest);
        ValidateQrResponse response = new ValidateQrResponse();

        String qrString = validateQrRequest.getQrString().trim();

        if (!qrString.toLowerCase().startsWith("upi://pay"))
            throw new FinalUdioException(UPICodes.INVALID_QR_STRING, UPICodes.INVALID_QR_STRING_MSG);
        else
        {
            UpiQrStrDecoder urlDecoder = new UpiQrStrDecoder(qrString);

            if (UpiUtil.isStringEmpty(urlDecoder.getPa()))
                throw new FinalUdioException(UPICodes.INVALID_QR_STRING, UPICodes.INVALID_QR_STRING_MSG);

            if (UpiUtil.isStringNotEmpty(urlDecoder.getCurrencyCode()) && !urlDecoder.getCurrencyCode().equalsIgnoreCase(UPIConstants.INR))
                throw new FinalUdioException(UPICodes.INVALID_QR_STRING, UPICodes.INVALID_QR_STRING_MSG);

            if (!UPIConstants.ALLOWED_INITIATION_MODE.contains(urlDecoder.getInitiationMode()))
                throw new FinalUdioException(UPICodes.INVALID_QR_STRING, UPICodes.INVALID_QR_STRING_MSG);
            // Need to check the cu, cc
            response.setAmount(urlDecoder.getAmount());
            response.setPayeeName(urlDecoder.getPn());
            response.setPayeeAddress(urlDecoder.getPa());
            response.setNote(urlDecoder.getNarration());

            ValidateVpaRequest validateVpaRequest = new ValidateVpaRequest();
            validateVpaRequest.setVpa(response.getPayeeAddress());
            validateVpaRequest.setValidationSource(String.valueOf(UpiEnums.ValidationSource.pay));
            if (validateVpa)
            {
                UpiValidateVpaResponse validateVpaResponse = validateVpa(userData, validateVpaRequest);
                response.setValidateVpaResponse(validateVpaResponse);
            }
        }

        return response;
    }

    private UpiValidateVpaResponse validateVpa(UserData userData, ValidateVpaRequest validateVpaRequest) {
        return null;
    }
}
