package upi.utils;

import upi.constant.UPIConstants;
import upi.model.db.UpiCustomerModel;
import upi.model.db.UpiTransactionModel;
import upi.model.olive.request.OliveTxnRequest;
import upi.model.olive.response.OliveTxnResponse;
import upi.model.olive.response.ProviderResponse;
import upi.model.olive.response.ProviderUpiTransactionResponse;
import upi.model.request.UpiPaymentRequest;
import upi.utils.enums.UpiEnums;
import upi.websecurity.SecurityConfig;

import java.util.Objects;

public class OliveConverterUtils {

    public static OliveTxnRequest prepareMakePaymentRequest(UpiTransactionModel upiTransactionModel, UpiPaymentRequest upiPaymentRequest, UpiCustomerModel upiCustomerModel) {

        OliveTxnRequest oliveTxnRequest = new OliveTxnRequest();

        OliveTxnRequest.DeviceInfo deviceInfo = oliveTxnRequest.new DeviceInfo();
        oliveTxnRequest.setDevice(deviceInfo);
        OliveTxnRequest.PayerInfo payerInfo = oliveTxnRequest.new PayerInfo();
        oliveTxnRequest.setPayerinfo(payerInfo);
        OliveTxnRequest.PayeeInfo payeeInfo = oliveTxnRequest.new PayeeInfo();
        oliveTxnRequest.setPayeeinfo(payeeInfo);

        oliveTxnRequest.setTrantype(upiTransactionModel.getTxnType().getProviderTxnType());
        oliveTxnRequest.setTxnid(upiTransactionModel.getTxnCode());
        oliveTxnRequest.setOrderid(upiTransactionModel.getRefId());
        oliveTxnRequest.setAmount(String.format("%.2f", upiTransactionModel.getAmount()));
        oliveTxnRequest.setRemarks(upiTransactionModel.getNarration());
        oliveTxnRequest.setPayrefnumber(upiTransactionModel.getTxnCode());
        oliveTxnRequest.setAppid(upiTransactionModel.getAppId());

        deviceInfo.setAppid(upiTransactionModel.getAppId());
        deviceInfo.setCapability("");
        deviceInfo.setIp(upiTransactionModel.getIpAddress());
        deviceInfo.setLocation(upiTransactionModel.getLocation());
        deviceInfo.setMobile(UPIConstants.IND_COUNTRY_CODE + upiCustomerModel.getMobileNumber());
        deviceInfo.setId(SecurityConfig.getDeviceId());
        deviceInfo.setOs(upiTransactionModel.getOs());
        deviceInfo.setType(UpiEnums.OliveDeviceType.MOB.name());
        deviceInfo.setGeocode(upiTransactionModel.getLat() + "," + upiTransactionModel.getLongitude());

        payerInfo.setName(upiTransactionModel.getPayerName());
        payerInfo.setAccountnumber(upiTransactionModel.getPayerAccountNumber());
        payerInfo.setVpa(upiTransactionModel.getPayerAddress());
        payerInfo.setMcc(upiTransactionModel.getPayerMcc());
        payerInfo.setMobile(UPIConstants.IND_COUNTRY_CODE + upiTransactionModel.getPayerMobileNumber());
        payerInfo.setAccounttype(upiTransactionModel.getPayerAccountType());
        payerInfo.setIfsc(upiTransactionModel.getPayerIfsc());

        payeeInfo.setName(upiTransactionModel.getPayeeName());
        payeeInfo.setVpa(upiTransactionModel.getPayeeAddress());
        payeeInfo.setMcc(upiTransactionModel.getPayeeMcc());
        return oliveTxnRequest;
    }

    public static ProviderUpiTransactionResponse prepareUpiTransactionResponse(ProviderResponse<OliveTxnResponse> oliveResponse) {
        ProviderUpiTransactionResponse response = new ProviderUpiTransactionResponse();
        OliveTxnResponse apiResponse = (OliveTxnResponse) oliveResponse.getResponse();

        response.setSuccess(Boolean.FALSE);
        if (Objects.nonNull(apiResponse)) {
            response.setCode(apiResponse.getCode());
            response.setSubcode(apiResponse.getSubcode());
            response.setSubresult(apiResponse.getSubresult());
            response.setLatency(apiResponse.getLatency());
            if (UpiEnums.OliveApiResponseStatus.SUCCESS.getCode().equals(apiResponse.getCode())) {
                response.setSuccess(Boolean.TRUE);
            }
        }

        return response;
    }
}
