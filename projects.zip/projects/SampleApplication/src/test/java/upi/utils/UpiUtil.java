package upi.utils;

import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.util.StringUtils;
import upi.constant.UPIConstants;
import upi.exception.FinalUdioException;
import upi.model.db.*;
import upi.model.request.UpiPaymentRequest;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.Calendar;
import java.util.Objects;

import static com.sun.xml.internal.ws.spi.db.BindingContextFactory.LOGGER;

public class UpiUtil {

    public static Double getDoubleForStringNullable(String value) {
        try {
            return Double.valueOf(value);
        } catch (NumberFormatException | NullPointerException e) {
            return null;
        }
    }

    public static boolean isStringNotEmpty(String str) {
        return !isStringEmpty(str);
    }

    public static boolean isStringEmpty(String str) {
        return (str == null || str.trim().isEmpty());
    }

    public static Timestamp getNow() {
        Calendar c = Calendar.getInstance();
        return Timestamp.from(Instant.ofEpochMilli(c.getTimeInMillis()));
    }

    public static boolean isPinMatching(String mpin, String mobileNumber, String encryptedMPin)
    {
        try
        {
            return BCrypt.checkpw(new StringBuffer(mpin.trim()).append(mobileNumber.trim()).toString(), encryptedMPin);
        }
        catch (Exception e)
        {
            LOGGER.info("Exception occured in Pin Matching.");
            return false;
        }
    }

    public static boolean isValidDhaniUpiAddress(String payeeAddress) {
        return true;
    }

    public static boolean isValidCreditlineApplication(CreditlineApplication creditApplication) {
        return true;
    }

    public UpiValidatedVpaModel getActiveValidateVpaModel(String payeeAddress) throws FinalUdioException {

        return null;
    }

    public String generateOliveUpiTxnCode()
    {
        return generateRandomAlphanumericStringWithPrefix("TSP", 35);
    }

    public static String generateRandomAlphanumericStringWithPrefix(String prefix, int length) {
        if (isStringEmpty(prefix)) {
            prefix = "";
        } else {
            prefix = prefix.toUpperCase();
        }

        StringBuilder b = new StringBuilder(prefix);
        b.append(generateRandomAlphanumericString(length - b.length()));

        return b.toString();
    }

    public static char[] generateRandomAlphanumericString(int i) {
        return null;
    }

    public UpiTransactionModel genUpiTransaction(VpaModel vpaModel, UpiValidatedVpaModel validatedVpaModel, UpiPaymentRequest upiPaymentRequest, double creditAmount, UpiCustomerModel upiCustomerModel, UpiUtil upiUtils) {
        UpiTransactionModel upiTransactionModel = new UpiTransactionModel();
        return upiTransactionModel;
    }
}
