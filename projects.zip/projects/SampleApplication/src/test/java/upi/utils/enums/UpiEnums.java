package upi.utils.enums;

import java.util.HashMap;
import java.util.Map;

public class UpiEnums {

    public static enum OliveDeviceType {
        MOB
    }

    public static enum OliveApiResponseStatus
    {
        SUCCESS("00000"), TIMEOUT("00091"), FAILURE("00001"), TRANSACTION_NOT_PERMITTED_TO_BENEFICIARY("XQ"), INACTIVE_ACCOUNT("ZY"), BENEFICIARY_ACCOUNT_NOT_EXIST("XI");

        private String code;

        OliveApiResponseStatus(String code)
        {
            this.code = code;
        }

        public String getCode()
        {
            return this.code;
        }
    }

    public static enum UpiCustomerType
    {
        customer("CUSTOMER"), merchant("MERCHANT");

        private String oliveCustomerType;

        UpiCustomerType(String oliveCustomerType)
        {
            this.oliveCustomerType = oliveCustomerType;
        }

        public String getOliveCustomerType()
        {
            return this.oliveCustomerType;
        }

        private static final Map<String, UpiCustomerType> oliveCustomerStatusToUpiCustomerType = new HashMap<String, UpiCustomerType>()
        {
            {
                put(UpiCustomerType.customer.oliveCustomerType, UpiCustomerType.customer);
                put(UpiCustomerType.merchant.oliveCustomerType, UpiCustomerType.merchant);
            }
        };
    }

    public static enum UpiCustomerStatus
    {
        active(ActiveDisplayStatus), blocked(BlockedDisplayStatus), na(PendingStatus);

        private String displayStatus;

        UpiCustomerStatus(String displayStatus)
        {
            this.displayStatus = displayStatus;
        }

        public String getDisplayStatus()
        {
            return this.displayStatus;
        }
    }

    public static enum UpiTransactionStatus
    {
        created("failed"), initiated("pending"), wallet_debited("pending"), wallet_credited("pending"), waiting_for_webhook("pending"), success("success"), failed("failed"), pending("pending"), expired("failed"), declined("declined");

        private String displayStatus;

        UpiTransactionStatus(String displayStatus)
        {
            this.displayStatus = displayStatus;
        }

        public String getDisplayStatus()
        {
            return this.displayStatus;
        }
    }

    public static enum UpiInitiationMode
    {
        default_mode("00"), static_qr_code("01"), static_secure_qr_code("02"), intent("04"), secure_intent("05"), nfc("06"), ble("07"), uhf("08"), mandate("11"), static_secure_qr_mandate(
            "13"), restricted("14"), dynamic_qr_code("15"), dynamic_secure_qr_code("16"), dynamic_secure_qa_mandate("17"), atmqr("18");

        private String code;

        UpiInitiationMode(String code)
        {
            this.code = code;
        }

        public String getCode()
        {
            return code;
        }
        private static final Map<String, UpiInitiationMode> providerInitmodeToInitmode = new HashMap<String, UpiInitiationMode>()
        {
            {
                put(UpiInitiationMode.default_mode.code, UpiInitiationMode.default_mode);
                put(UpiInitiationMode.static_qr_code.code, UpiInitiationMode.static_qr_code);
                put(UpiInitiationMode.ble.code, UpiInitiationMode.ble);
                put(UpiInitiationMode.default_mode.code, UpiInitiationMode.default_mode);
                put(UpiInitiationMode.atmqr.code, UpiInitiationMode.atmqr);
                put(UpiInitiationMode.dynamic_qr_code.code, UpiInitiationMode.dynamic_qr_code);
                put(UpiInitiationMode.restricted.code, UpiInitiationMode.restricted);
                put(UpiInitiationMode.mandate.code, UpiInitiationMode.mandate);
                put(UpiInitiationMode.secure_intent.code, UpiInitiationMode.secure_intent);
                put(UpiInitiationMode.static_secure_qr_code.code, UpiInitiationMode.static_secure_qr_code);
                put(UpiInitiationMode.nfc.code, UpiInitiationMode.nfc);
                put(UpiInitiationMode.intent.code, UpiInitiationMode.intent);
                put(UpiInitiationMode.uhf.code, UpiInitiationMode.uhf);
                put(UpiInitiationMode.dynamic_secure_qr_code.code, UpiInitiationMode.dynamic_secure_qr_code);
                put(UpiInitiationMode.dynamic_secure_qa_mandate.code, UpiInitiationMode.dynamic_secure_qa_mandate);
                put(UpiInitiationMode.static_secure_qr_mandate.code, UpiInitiationMode.static_secure_qr_mandate);
            }
        };

        public static UpiInitiationMode getUpiInitmodeFromProviderInitmode(String initmode)
        {
            return providerInitmodeToInitmode.get(initmode);
        }
    }

    public static enum QRType {
        staticQR, dynamicQR
    }

    public static enum UpiConfirmationSubType
    {
        RespPay, ReqTxnConfirmation, UDIR, COLLECT
    }

    public static enum PaymentType
    {
        send_money, scan_and_pay, repayment, request_money
    }

    public static enum VpaRegistrationStatus
    {
        initiated, retry, retry_cron, failed, registered, na
    }

    public static enum UpiProvider
    {
        olive
    }

    public static enum VpaRegistrationSource
    {
        api, cron
    }

    public static String PendingStatus = "pending";
    public static String BlockedDisplayStatus = "blocked";
    public static String ActiveDisplayStatus = "active";

    public static enum VpaStatus
    {
        active(ActiveDisplayStatus), unlinked(BlockedDisplayStatus), na(PendingStatus);

        private String displayStatus;

        VpaStatus(String displayStatus)
        {
            this.displayStatus = displayStatus;
        }

        public String getDisplayStatus()
        {
            return this.displayStatus;
        }
    }

    public static enum UpiTxnType
    {
        pay("PAY"), credit("CREDIT"), creditenq("CREDITENQ"), debitreversal("REVDEBIT"), collect("COLLECT"), collectapprove("COLLECTAPPROVE"), collectreject("COLLECTREJECT"), collectpay("COLLECTPAY");

        private String txnType;

        UpiTxnType(String txnType)
        {
            this.txnType = txnType;
        }

        public String getProviderTxnType() {return this.txnType;}

        private static final Map<String, UpiTxnType> providerTxnTypeToTxnType = new HashMap<String, UpiTxnType>()
        {
            {
                put(UpiTxnType.pay.txnType, UpiTxnType.pay);
                put(UpiTxnType.credit.txnType, UpiTxnType.credit);
                put(UpiTxnType.creditenq.txnType, UpiTxnType.creditenq);
                put(UpiTxnType.debitreversal.txnType, UpiTxnType.debitreversal);
                put(UpiTxnType.collect.txnType, UpiTxnType.collect);
                put(UpiTxnType.collectapprove.txnType, UpiTxnType.collectapprove);
                put(UpiTxnType.collectreject.txnType, UpiTxnType.collectreject);
                put(UpiTxnType.collectpay.txnType, UpiTxnType.collectpay);
            }
        };

        public static UpiTxnType getUpiTxnTypeFromProviderTxnType(String txnType)
        {
            return providerTxnTypeToTxnType.get(txnType);
        }

    }

    public static enum UpiTransactionPurpose
    {
        DEFAULT("00"), SEBI("01"), AMC("02"), Travel("03"), Hospitality("04"), Hospital("05"), Telecom("06"), Insurance("07"), Education("08"), Gifting("09"), Others("10") ;

        private String code;

        UpiTransactionPurpose(String code)
        {
            this.code = code ;
        }

        public String getCode()
        {
            return code;
        }

        private static final Map<String, UpiTransactionPurpose> providerPurposeToPurpose = new HashMap<String, UpiTransactionPurpose>()
        {
            {
                put(UpiTransactionPurpose.AMC.code, UpiTransactionPurpose.AMC);
                put(UpiTransactionPurpose.DEFAULT.getCode(), UpiTransactionPurpose.DEFAULT);
                put(UpiTransactionPurpose.Others.code, UpiTransactionPurpose.Others);
                put(UpiTransactionPurpose.SEBI.code, UpiTransactionPurpose.SEBI);
                put(UpiTransactionPurpose.Hospitality.code, UpiTransactionPurpose.Hospitality);
                put(UpiTransactionPurpose.Travel.code, UpiTransactionPurpose.Travel);
                put(UpiTransactionPurpose.Hospital.code, UpiTransactionPurpose.Hospital);
                put(UpiTransactionPurpose.Gifting.code, UpiTransactionPurpose.Gifting);
                put(UpiTransactionPurpose.Insurance.code, UpiTransactionPurpose.Insurance);
                put(UpiTransactionPurpose.Education.code, UpiTransactionPurpose.Education);
                put(UpiTransactionPurpose.Telecom.code, UpiTransactionPurpose.Telecom);
            }
        };

        public static UpiTransactionPurpose getUpiPurposeFromProviderPurpose(String purpose)
        {
            return providerPurposeToPurpose.get(purpose);
        }
    }

    public static enum Mode
    {
        dr, cr
    }

    public static enum UpiTransactionInitiator
    {
        npci, dhani
    }

    public static enum CollectType {
        Approve, Decline, CreditValReceived
    }

    public static enum ValidationSource
    {
        pay,collect,collectaction,blockuser
    }

    public static enum ValidateVpaStatus
    {

        initiated("failed"), waiting_for_webhook("pending"), verified("verified"), failed("failed"), expired("failed"), na("failed");

        private final String displayStatus;

        ValidateVpaStatus(String displayStatus)
        {
            this.displayStatus = displayStatus;
        }

        public String getDisplayStatus()
        {
            return this.displayStatus;
        }
    }

    public static enum UpiBlockedUserType
    {
        source, destination
    }

    public static enum UserStatus
    {
        active, blocked, pending
    }

    public static enum Source {
        dhani, upi
    }

    public static enum CreditLineProductType {
        DOF,supersaver
    }
}
