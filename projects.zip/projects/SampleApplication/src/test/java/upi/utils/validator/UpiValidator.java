package upi.utils.validator;


import upi.constant.UPICodes;
import upi.exception.FinalUdioException;
import upi.model.request.UpiPaymentRequest;
import upi.model.request.ValidateQrRequest;
import upi.utils.UpiUtil;
import upi.utils.enums.UpiEnums;
import upi.websecurity.SecurityConfig;

import java.util.Objects;

public class UpiValidator {

    public static void validateUpiPayment(UpiPaymentRequest upiPaymentRequest) throws FinalUdioException
    {

        validateDeviceDetails();

        if (Objects.isNull(upiPaymentRequest.getPaymentType()))
            throw new FinalUdioException(UPICodes.INVALID_PAYMENT_TYPE, UPICodes.INVALID_PAYMENT_TYPE_MSG);

        if (Objects.isNull(upiPaymentRequest.getAmount()) || upiPaymentRequest.getAmount() <= 0)
            throw new FinalUdioException(UPICodes.INVALID_AMOUNT, UPICodes.INVALID_AMOUNT_MSG);

        if (UpiUtil.isStringEmpty(upiPaymentRequest.getMpin()))
            throw new FinalUdioException(UPICodes.NO_MPIN_FOUND, UPICodes.NO_MPIN_FOUND_MSG);

        if (UpiUtil.isStringNotEmpty(upiPaymentRequest.getNote()) && upiPaymentRequest.getNote().length() > 100)
            throw new FinalUdioException(UPICodes.INVALID_NARRATION_LENGTH, UPICodes.INVALID_NARRATION_LENGTH_MSG);

        if (upiPaymentRequest.getPaymentType() == UpiEnums.PaymentType.send_money)
        {
            if (UpiUtil.isStringEmpty(upiPaymentRequest.getPayeeAddress()))
                throw new FinalUdioException(UPICodes.PAYEE_ADDRESS_REQUIRED, UPICodes.PAYEE_ADDRESS_REQUIRED_MSG);
        }
        else if (upiPaymentRequest.getPaymentType() == UpiEnums.PaymentType.scan_and_pay)
        {
            if (UpiUtil.isStringEmpty(upiPaymentRequest.getQrUrl()))
                throw new FinalUdioException(UPICodes.EMPTY_QR_STRING, UPICodes.EMPTY_QR_STRING_MSG);
        }
        else if (upiPaymentRequest.getPaymentType() == UpiEnums.PaymentType.repayment)
        {
            if (UpiUtil.isStringEmpty(upiPaymentRequest.getTxnCode()))
                throw new FinalUdioException(UPICodes.NO_TXN_ID_PASSED, UPICodes.NO_TXN_ID_PASSED_MSG);

            if (UpiUtil.isStringEmpty(upiPaymentRequest.getTxnType()))
                throw new FinalUdioException(UPICodes.NO_TXN_TYPE_PASSED, UPICodes.NO_TXN_TYPE_PASSED_MSG);
        }
    }

    public static void validateDeviceDetails() throws FinalUdioException
    {
        Double lat = SecurityConfig.getLatitude();
        Double longitude = SecurityConfig.getLongitude();

        if (Objects.isNull(lat) || Objects.isNull(longitude) || lat == 0.0 || longitude == 0.0)
            throw new FinalUdioException(UPICodes.INVALID_LAT_LONG, UPICodes.INVALID_LAT_LONG_MSG);

        if (UpiUtil.isStringEmpty(SecurityConfig.getRequestIp()))
            throw new FinalUdioException(UPICodes.NO_IP_ADDRESS, UPICodes.NO_IP_ADDRESS_MSG);

        if (UpiUtil.isStringEmpty(SecurityConfig.getRequestSourceOsName()))
            throw new FinalUdioException(UPICodes.NO_OS_PRESENT, UPICodes.NO_OS_PRESENT_MSG);
    }


    public static void validateQrRequest(ValidateQrRequest validateQrRequest) throws FinalUdioException
    {
        if (UpiUtil.isStringEmpty(validateQrRequest.getQrString()))
            throw new FinalUdioException(UPICodes.EMPTY_QR_STRING, UPICodes.EMPTY_QR_STRING_MSG);
    }
}
