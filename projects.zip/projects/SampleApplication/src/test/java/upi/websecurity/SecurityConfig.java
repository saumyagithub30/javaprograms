package upi.websecurity;

//import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import upi.model.request.DeviceDataRequestHeader;
import upi.utils.UpiUtil;

public class SecurityConfig {

    private static final ThreadLocal<DeviceDataRequestHeader> DEVICE_DATA_HOLDER = new ThreadLocal<DeviceDataRequestHeader>();

    public static String getDeviceId()
    {
        DeviceDataRequestHeader data = getDeviceDataSpecificRequest();
        return (data == null) ? null : data.getUid();
    }

    public static String getRequestSourceOsName()
    {
        DeviceDataRequestHeader data = getDeviceDataSpecificRequest();
        return data == null ? "Android" : data.getOsName();
    }

    public static String getRequestIp()
    {
        DeviceDataRequestHeader data = getDeviceDataSpecificRequest();
        return (data == null) ? null : data.getIpAddress();
    }

    public static Double getLatitude()
    {
        DeviceDataRequestHeader data = getDeviceDataSpecificRequest();
        return (data == null) ? null : UpiUtil.getDoubleForStringNullable(data.getLatitude());
    }


    public static boolean isLocationMissing()
    {
        return getLatitude() == null || getLongitude() == null;
    }

    public static Double getLongitude()
    {
        DeviceDataRequestHeader data = getDeviceDataSpecificRequest();
        return (data == null) ? null : UpiUtil.getDoubleForStringNullable(data.getLongitude());
    }

    public static DeviceDataRequestHeader getDeviceDataSpecificRequest()
    {
        return DEVICE_DATA_HOLDER.get();
    }
}
