package com.example.pluang.enums;

public enum Candle {
    GREEN,
    RED
}
