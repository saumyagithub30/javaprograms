package com.example.pluang.enums;

public enum Strategy {
    Long,
    Short
}
