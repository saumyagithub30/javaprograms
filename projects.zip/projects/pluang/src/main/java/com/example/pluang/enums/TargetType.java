package com.example.pluang.enums;

public enum TargetType {
    High,
    Close,
    Low
}
