package com.company.conditions;

import com.company.model.Piece;

public interface MoveBaseCondition {

    /**
     * It provides the base condition for a piece to make a move. The piece would only be allowed to move from its current
     * position if the condition fulfills.
     */
    boolean isBaseConditionFullfilled(Piece piece);

}
