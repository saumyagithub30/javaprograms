package com.company.conditions;

import com.company.model.Board;
import com.company.model.Cell;
import com.company.model.Piece;
import com.company.model.Player;

public interface PieceCellOccupyBlocker {
    /**
     * This check tells whether a piece can occupy a given cell in the board or not.
     */

    boolean isCellNonOccupiableForPiece(Cell cell, Piece piece, Board board, Player player);
}
