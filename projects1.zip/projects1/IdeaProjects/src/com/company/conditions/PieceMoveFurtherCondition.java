package com.company.conditions;

import com.company.model.Board;
import com.company.model.Cell;
import com.company.model.Piece;

public interface PieceMoveFurtherCondition {
    boolean canPieceMoveFurtherFromCell(Piece piece, Cell cell, Board board);
}
