package com.company.enums;

public class Enums {
    public enum Color {
        BLACK,
        WHITE
    }

    public enum PieceType {
        KING,
        QUEEN,
        ROOK,
        KNIGHT,
        BISHOP,
        PAWN
    }
}
