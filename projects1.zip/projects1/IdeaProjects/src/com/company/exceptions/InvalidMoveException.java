package com.company.exceptions;

public class InvalidMoveException extends RuntimeException{
}
