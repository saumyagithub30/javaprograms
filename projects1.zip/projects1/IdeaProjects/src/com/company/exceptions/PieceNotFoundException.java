package com.company.exceptions;

public class PieceNotFoundException extends RuntimeException{
}
