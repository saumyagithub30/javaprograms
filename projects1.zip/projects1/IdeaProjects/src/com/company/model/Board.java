package com.company.model;

import lombok.Getter;

@Getter
public class Board {

    private int boardSize;
    private Cell[][] cells;

    public Board(int boardSize, Cell[][] cells) {
        this.boardSize = boardSize;
        this.cells = cells;
    }


}
