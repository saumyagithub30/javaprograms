package com.company.moves;

import com.company.conditions.MoveBaseCondition;
import com.company.conditions.PieceCellOccupyBlocker;
import com.company.conditions.PieceMoveFurtherCondition;
import com.company.model.Board;
import com.company.model.Cell;
import com.company.model.Piece;
import com.company.model.Player;

import java.util.List;

public abstract class PossibleMovesProvider {
    int maxSteps;
    MoveBaseCondition baseCondition;
    PieceMoveFurtherCondition moveFurtherCondition;
    PieceCellOccupyBlocker baseBlocker;

    public PossibleMovesProvider(int maxSteps, MoveBaseCondition baseCondition, PieceMoveFurtherCondition moveFurtherCondition, PieceCellOccupyBlocker baseBlocker) {
        this.maxSteps = maxSteps;
        this.baseCondition = baseCondition;
        this.moveFurtherCondition = moveFurtherCondition;
        this.baseBlocker = baseBlocker;
    }

    /**
     * Public method which actually gives all possible cells which can be reached via current type of move.
     */

    public List<Cell> possibleMoves(Piece piece, Board board, List<PieceCellOccupyBlocker> additionalBlockers, Player player) {
        if (baseCondition.isBaseConditionFullfilled(piece)) {
            return possibleMovesAsPerCurrentType(piece, board, additionalBlockers, player);
        }
        return null;
    }

    /**
     * Abstract method which needs to be implemented by each type of move to give possible moves as per their behaviour.
     */
    protected abstract List<Cell> possibleMovesAsPerCurrentType(Piece piece, Board board, List<PieceCellOccupyBlocker> additionalBlockers, Player player);


}
