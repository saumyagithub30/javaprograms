package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here

        Solution s = new Solution();
        int[][] ladder = new int[2][2];
        int[][] snake = new int[1][2];
        ladder[0][0] = 5;
        ladder[0][1] = 66;
        ladder[1][0] = 9;
        ladder[1][1] = 88;
        snake[0][0] = 67;
        snake[0][1] = 8;
        int diceCount = s.snakeLadder(ladder, snake);
        System.out.println("Dice count is:" + diceCount);
    }
}
