package com.company;

import java.util.*;

public class Solution {
    public int snakeLadder(int[][] A, int[][] B) {
        Map<Integer, Integer> ladderMap = new HashMap<>();
        for(int[] val: A) {
            ladderMap.put(val[0], val[1]);
        }

        Map<Integer, Integer> snakeMap = new HashMap<>();
        for(int[] val: B) {
            snakeMap.put(val[0], val[1]);
        }

        Queue<Integer> queue = new LinkedList<>();
        queue.add(1);

        Set<Integer> visited = new HashSet<>();
        visited.add(1);

        int dicecount = 0;

        while(!queue.isEmpty()) {
            int size = queue.size();

            for(int i=0; i<size; i++) {
                int val = queue.poll();

                if(val == 100) {
                    return dicecount;
                }

                for(int j=1; j<=6; j++) {
                    int newVal = val + j;

                    if(!visited.contains(newVal)) {
                        if(ladderMap.containsKey(newVal)) {
                            queue.add(ladderMap.get(newVal));
                            visited.add(ladderMap.get(newVal));
                        } else if (snakeMap.containsKey(newVal)) {
                            queue.add(snakeMap.get(newVal));
                            visited.add(snakeMap.get(newVal));
                        } else {
                            queue.add(newVal);
                        }
                        visited.add(newVal);
                    }
                }

            }
            dicecount++;
        }

        return -1;
    }
}
