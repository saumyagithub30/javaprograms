package cabbooking.controller;

import cabbooking.database.CabTable;
import cabbooking.database.TripTable;
import cabbooking.model.Cab;
import cabbooking.model.Location;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@EnableAutoConfiguration
public class CabController {

    @Autowired
    private CabTable cabTable;

    @Autowired
    private TripTable tripTable;


    @RequestMapping(value = "/register/cab", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity registerCab(@RequestHeader final String cabId, @RequestHeader final String driverName) {
        cabTable.createCab(new Cab(cabId, driverName));
        return ResponseEntity.ok("");
    }

    @RequestMapping(value = "/update/cab/location", method = RequestMethod.POST)
    public ResponseEntity updateCabLocation(final String cabId, final Double newX, final Double newY) {
        cabTable.updateCabLocation(cabId, new Location(newX, newY));
        return ResponseEntity.ok("");
    }

    @RequestMapping(value = "/update/cab/availability", method = RequestMethod.POST)
    public ResponseEntity updateCabAvailability(final String cabId, final Boolean isAvailable) {
        cabTable.updateCabAvailability(cabId, isAvailable);
        return ResponseEntity.ok("");
    }

    @RequestMapping(value = "/update/cab/endtrip", method = RequestMethod.POST)
    public ResponseEntity endTrip(final String cabId) {
        tripTable.endTrip(cabTable.getCab(cabId));
        return ResponseEntity.ok("");
    }
}
