package cabbooking.controller;

import cabbooking.database.RiderTable;
import cabbooking.database.TripTable;
import cabbooking.model.Location;
import cabbooking.model.Rider;
import cabbooking.model.Trip;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class RiderController {

    @Autowired
    RiderTable riderTable;

    @Autowired
    TripTable tripTable;

    @RequestMapping(value = "/register/rider", method = RequestMethod.POST)
    public ResponseEntity registerRider(final String riderId, final String riderName) {
        riderTable.createRider(new Rider(riderId, riderName));
        return ResponseEntity.ok("");
    }

    @RequestMapping(value = "/bookTrip", method = RequestMethod.POST)
    public ResponseEntity bookTrip(final String riderId, final Double sourceX, final Double sourceY, final Double destX, final Double destY) {
        tripTable.createTrip(riderTable.getRider(riderId), new Location(sourceX, sourceY), new Location(destX, destY) );
        return ResponseEntity.ok("");
    }

    @RequestMapping(value = "/bookTrip", method = RequestMethod.GET)
    public ResponseEntity getTripHistory(final String riderId) {
        List<Trip> trips = tripTable.tripHistory(riderId);
        return ResponseEntity.ok(trips);
    }
}
