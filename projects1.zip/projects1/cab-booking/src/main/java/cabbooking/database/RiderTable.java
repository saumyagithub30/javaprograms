package cabbooking.database;

import cabbooking.exceptions.RiderAlreadyExistsException;
import cabbooking.exceptions.RiderNotFoundException;
import cabbooking.model.Rider;
import lombok.NonNull;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

@Component
public class RiderTable {

    Map<String, Rider> riders = new HashMap<>();

    public void createRider(@NonNull final Rider rider) {
        if(riders.containsKey(rider.getRiderId())) {
            throw new RiderAlreadyExistsException();
        }
        riders.put(rider.getRiderId(), rider);
    }

    public Rider getRider(@NonNull final String riderId) {
        if(!riders.containsKey(riderId)) {
            throw new RiderNotFoundException();
        }
        return riders.get(riderId);
    }


}
