package cabbooking.database;

import cabbooking.exceptions.NoCabsAvailableException;
import cabbooking.exceptions.TripNotFoundException;
import cabbooking.model.Cab;
import cabbooking.model.Location;
import cabbooking.model.Rider;
import cabbooking.model.Trip;
import cabbooking.strategies.CabMatchingStrategies;
import lombok.NonNull;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
@Component
public class TripTable {

    private static final Double MAX_ALLOWED_TRIP_MATCHING_DISTANCE = 10.0;
    private Map<String, List<Trip>> trips = new HashMap<>();

    private CabTable cabTable;
    private RiderTable riderTable;
    private CabMatchingStrategies cabMatchingStrategies;

    public TripTable(CabTable cabTable, RiderTable riderTable, CabMatchingStrategies cabMatchingStrategies) {
        this.cabTable = cabTable;
        this.riderTable = riderTable;
        this.cabMatchingStrategies = cabMatchingStrategies;
    }

    public void createTrip(@NonNull final Rider rider, @NonNull final Location fromPoint, @NonNull final Location toPoint) {
        final List<Cab> closeByCabs = cabTable.getCabs(fromPoint, MAX_ALLOWED_TRIP_MATCHING_DISTANCE);
        final Cab selectedCab = cabMatchingStrategies.matchCabToRider(rider, closeByCabs, fromPoint, toPoint);
        if(selectedCab == null) {
            throw new NoCabsAvailableException();
        }
        final Trip newTrip = new Trip(selectedCab,rider, fromPoint, toPoint, 100.00);
        if(!trips.containsKey(rider.getRiderId())) {
            trips.put(rider.getRiderId(), new ArrayList<>());
        }
        trips.get(rider.getRiderId()).add(newTrip);
        selectedCab.setCurrentTrip(newTrip);
    }

    public List<Trip> tripHistory(@NonNull final String riderId) {
        return trips.get(riderId);
    }

    public void endTrip(@NonNull final Cab cab) {
        if(cab.getCurrentTrip() == null) {
            throw new TripNotFoundException();
        }
        cab.getCurrentTrip().endTrip();
        cab.setCurrentTrip(null);
    }
}
