package cabbooking.exceptions;

public class CabAlreadyExistsException extends RuntimeException{
}
