package cabbooking.exceptions;

public class CabNotFoundException extends RuntimeException{
}
