package cabbooking.exceptions;

public class NoCabsAvailableException extends RuntimeException{
}
