package cabbooking.exceptions;

public class RiderAlreadyExistsException extends RuntimeException{
}
