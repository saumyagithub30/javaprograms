package cabbooking.exceptions;

public class RiderNotFoundException extends RuntimeException{
}
