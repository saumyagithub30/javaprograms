package cabbooking.exceptions;

public class TripNotFoundException extends RuntimeException{
}
