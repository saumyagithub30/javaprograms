package cabbooking.model;

import lombok.Getter;
import lombok.Setter;

@Getter
public class Cab {
    private String cabId;
    private String driverName;

    @Setter
    private Trip currentTrip;
    @Setter
    private Location currentLocation;
    @Setter
    private Boolean isAvailable;

    public Cab(String cabId, String driverName) {
        this.cabId = cabId;
        this.driverName = driverName;
        this.isAvailable = true;
    }

    @Override
    public String toString() {
        return "Cab{" +
                "cabId='" + cabId + '\'' +
                ", driverName='" + driverName + '\'' +
                ", currentTrip=" + currentTrip +
                ", currentLocation=" + currentLocation +
                ", isAvailable=" + isAvailable +
                '}';
    }
}
