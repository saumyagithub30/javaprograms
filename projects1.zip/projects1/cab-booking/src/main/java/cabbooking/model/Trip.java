package cabbooking.model;

import lombok.NonNull;
import lombok.ToString;

enum TripStatus {
    IN_PROGRESS,
    FINISHED
}

@ToString
public class Trip {
    private Cab cab;
    private Rider rider;
    private TripStatus status;
    private Location fromPoint;
    private Location endPoint;
    private Double price;

    public Trip(@NonNull Cab cab, @NonNull Rider rider, @NonNull Location fromPoint, @NonNull Location endPoint, @NonNull Double price) {
        this.cab = cab;
        this.rider = rider;
        this.fromPoint = fromPoint;
        this.endPoint = endPoint;
        this.price = price;
        this.status = TripStatus.IN_PROGRESS;
    }

    public void endTrip() {
        this.status = TripStatus.FINISHED;
    }
}
