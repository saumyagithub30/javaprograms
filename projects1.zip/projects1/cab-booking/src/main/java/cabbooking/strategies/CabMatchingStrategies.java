package cabbooking.strategies;

import cabbooking.model.Cab;
import cabbooking.model.Location;
import cabbooking.model.Rider;
import org.springframework.stereotype.Component;

import java.util.List;


public interface CabMatchingStrategies {

    Cab matchCabToRider(Rider rider, List<Cab> availableCabs, Location fromPoint, Location toPoint);
}
