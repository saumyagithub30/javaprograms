package cabbooking.strategies;

import cabbooking.model.Cab;
import cabbooking.model.Location;
import cabbooking.model.Rider;
import lombok.NonNull;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class DefaultCabMatchingStrategy implements CabMatchingStrategies{
    @Override
    public Cab matchCabToRider(@NonNull final Rider rider,@NonNull final List<Cab> availableCabs,@NonNull final Location fromPoint, @NonNull final Location toPoint) {
        if(availableCabs.isEmpty()) {
            return null;
        }
        return availableCabs.get(0);
    }
}
